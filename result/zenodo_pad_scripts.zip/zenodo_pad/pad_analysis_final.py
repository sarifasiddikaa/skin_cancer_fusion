import os, sys, json, subprocess, warnings
import numpy as np, pandas as pd, torch, torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms
import torchvision.models as models
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, f1_score
from scipy.stats import ttest_rel, wilcoxon, spearmanr
from torch.cuda.amp import autocast, GradScaler
warnings.filterwarnings('ignore')
try:
    from captum.attr import IntegratedGradients
except ImportError:
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'captum', '-q'])
    from captum.attr import IntegratedGradients

# ---------------- CONFIG ----------------
INPUT_ROOT  = '/kaggle/input'
OUT_DIR     = '/kaggle/working'      # pad_* files from the training run must be in this folder
PRETRAINED  = True                   # for the new image-only baseline
EPOCHS_BASE = 15                     # same budget as the ISIC baselines
IG_N, IG_STEPS, N_BOOT = 100, 20, 1000
# ----------------------------------------
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.backends.cudnn.benchmark = True
print('Device:', device)

# ---------- load everything produced by the training run ----------
need = ['pad_meta_config.json', 'pad_final_predictions_per_sample.csv', 'pad_split_assignments.csv']
missing = [f for f in need if not os.path.exists(f'{OUT_DIR}/{f}')]
if missing:
    raise SystemExit(f'STOP: {missing} not found in {OUT_DIR}. Run this cell in the SAME session where the training cell finished.')
cfg =json.load(open(f'{OUT_DIR}/pad_meta_config.json'))
cat_cols, numeric_cols = cfg['cat_cols'], cfg['numeric_cols']
pred = pd.read_csv(f'{OUT_DIR}/pad_final_predictions_per_sample.csv')
splits = pd.read_csv(f'{OUT_DIR}/pad_split_assignments.csv')
SEEDS = sorted(pred['seed'].unique())
print('Seeds found:', SEEDS)

def find_file(root, name):
    for d, _, fs in os.walk(root):
        if name in fs: return os.path.join(d, name)
    raise FileNotFoundError(name)
meta_df = pd.read_csv(find_file(INPUT_ROOT, 'metadata.csv'))
meta_df['class'] = meta_df['diagnostic'].isin(['BCC', 'SCC', 'MEL']).astype(int)
meta_df['patient_id'] = meta_df['patient_id'].astype(str)
assert meta_df['img_id'].is_unique
meta_idx = meta_df.set_index('img_id')
IMAGE_LOOKUP = {}
for d, _, fs in os.walk(INPUT_ROOT):
    for f in fs:
        if f.lower().endswith(('.png', '.jpg', '.jpeg')): IMAGE_LOOKUP[f] = os.path.join(d, f)

def encode_metadata(df_in, medians, reference_columns=None):
    df_cat = pd.get_dummies(df_in[cat_cols].astype(str))
    df_num = df_in[numeric_cols].fillna(medians)
    out = pd.concat([df_num, df_cat], axis=1)
    if reference_columns is not None: out = out.reindex(columns=reference_columns, fill_value=0)
    return out

class SkinFusionDataset(Dataset):
    def __init__(self, df, meta_features, labels, transform=None):
        self.df = df.reset_index(drop=True); self.meta_features = meta_features.reset_index(drop=True)
        self.labels = labels; self.transform = transform; self.cache = {}; self.resize = transforms.Resize((224, 224))
    def __len__(self): return len(self.df)
    def __getitem__(self, idx):
        n = self.df.loc[idx, 'img_id']
        if n not in self.cache: self.cache[n] = self.resize(Image.open(IMAGE_LOOKUP[n]).convert('RGB'))
        image = self.cache[n].copy()
        if self.transform: image = self.transform(image)
        meta = torch.tensor(self.meta_features.iloc[idx].values.astype('float32'))
        return image, meta, torch.tensor(self.labels[idx], dtype=torch.long)

class MetaOnlyDataset(Dataset):
    def __init__(self, meta_features, labels):
        self.m = torch.tensor(meta_features.values.astype('float32')); self.y = torch.tensor(labels, dtype=torch.long)
    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.m[i], self.y[i]

norm = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
transform = transforms.Compose([transforms.ToTensor(), norm])
train_transform = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.2, contrast=0.2), transforms.ToTensor(), norm])

FREEZE_PATTERN = ['0.8.']
def _backbone(pretrained):
    eff = models.efficientnet_b3(weights='IMAGENET1K_V1' if pretrained else None)
    return nn.Sequential(eff.features, eff.avgpool)

class FusionModel(nn.Module):   # identical to the training script
    def __init__(self, meta_input_dim, num_classes=2, pretrained=False):
        super().__init__()
        self.image_branch = _backbone(pretrained)
        self.meta_branch = nn.Sequential(nn.Linear(meta_input_dim, 64), nn.ReLU(), nn.Linear(64, 32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(1536 + 32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        return self.classifier(torch.cat([self.image_branch(image).flatten(1), self.meta_branch(meta)], dim=1))

class MetaBlock(nn.Module):     # identical to the training script
    def __init__(self, image_feat_dim, meta_input_dim, num_classes=2, pretrained=False):
        super().__init__()
        self.image_branch = _backbone(pretrained)
        self.meta_gate = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Sigmoid())
        self.meta_bias = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Tanh())
        self.classifier = nn.Sequential(nn.Linear(image_feat_dim, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        f = self.image_branch(image).flatten(1)
        return self.classifier(f * self.meta_gate(meta) + self.meta_bias(meta))

class ImageOnlyModel(nn.Module):  # same image branch and head as MetaBlock, no metadata
    def __init__(self, num_classes=2, pretrained=True):
        super().__init__()
        self.image_branch = _backbone(pretrained)
        for n, p in self.image_branch.named_parameters(): p.requires_grad = any(n.startswith(k) for k in FREEZE_PATTERN)
        self.classifier = nn.Sequential(nn.Linear(1536, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image): return self.classifier(self.image_branch(image).flatten(1))

class MetaOnlyModel(nn.Module):   # same metadata branch as Fusion, same head, no image
    def __init__(self, meta_dim, num_classes=2):
        super().__init__()
        self.meta_branch = nn.Sequential(nn.Linear(meta_dim, 64), nn.ReLU(), nn.Linear(64, 32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, meta): return self.classifier(self.meta_branch(meta))

def run_epoch(model, loader, mode, criterion, opt, scaler):
    model.train()
    for b in loader:
        x, y = (b[0].to(device), b[1].to(device)) if mode == 'meta' else (b[0].to(device), b[2].to(device))
        opt.zero_grad()
        with autocast(): loss = criterion(model(x), y)
        scaler.scale(loss).backward(); scaler.step(opt); scaler.update()

def predict(model, loader, mode):
    model.eval(); probs, ys = [], []
    with torch.no_grad():
        for b in loader:
            x, y = (b[0].to(device), b[1]) if mode == 'meta' else (b[0].to(device), b[2])
            with autocast(): p = torch.softmax(model(x), 1)
            probs.append(p.float().cpu()); ys.append(y)
    return torch.cat(probs).numpy(), torch.cat(ys).numpy()

def train_best(model, mode, epochs, tl, vl, criterion):
    opt = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4, weight_decay=1e-3)
    scaler = GradScaler(); best, state = -1, None
    for ep in range(epochs):
        run_epoch(model, tl, mode, criterion, opt, scaler)
        pr, y = predict(model, vl, mode); acc = (pr.argmax(1) == y).mean()
        if acc > best: best, state = acc, {k: v.clone() for k, v in model.state_dict().items()}
    model.load_state_dict(state); return model

# =====================================================================
# PART 1: unimodal baselines on the SAME splits as Fusion / MetaBlock
# =====================================================================
print('\n========== PART 1: UNIMODAL BASELINES ==========')
base_rows = []
for seed in SEEDS:
    print(f'\n--- Baselines, seed {seed} ---')
    torch.manual_seed(seed); np.random.seed(seed); torch.cuda.manual_seed_all(seed)
    sp = splits[splits['seed'] == seed]
    def part(nm):
        d = meta_idx.loc[sp[sp['split'] == nm]['img_id']].reset_index()
        for c in cat_cols: d[c] = d[c].astype(str)
        return d
    train_df, val_df, test_df = part('train'), part('val'), part('test')
    assert len(set(train_df['patient_id']) & set(test_df['patient_id'])) == 0
    assert set(test_df['img_id']) == set(pred[pred['seed'] == seed]['img_id']), 'test set differs from Fusion/MetaBlock'
    med = train_df[numeric_cols].median()
    tm = encode_metadata(train_df, med); rc = tm.columns
    vm, sm = encode_metadata(val_df, med, rc), encode_metadata(test_df, med, rc)
    le = LabelEncoder(); le.fit(train_df['class'])
    ytr, yva, yte = le.transform(train_df['class']), le.transform(val_df['class']), le.transform(test_df['class'])
    cw = torch.tensor(compute_class_weight('balanced', classes=np.unique(ytr), y=ytr), dtype=torch.float32).to(device)
    crit = nn.CrossEntropyLoss(weight=cw)

    tl = DataLoader(SkinFusionDataset(train_df, tm, ytr, train_transform), batch_size=96, shuffle=True, num_workers=0, pin_memory=True)
    vl = DataLoader(SkinFusionDataset(val_df, vm, yva, transform), batch_size=96, num_workers=0, pin_memory=True)
    el = DataLoader(SkinFusionDataset(test_df, sm, yte, transform), batch_size=96, num_workers=0, pin_memory=True)
    mi = train_best(ImageOnlyModel(pretrained=PRETRAINED).to(device), 'img', EPOCHS_BASE, tl, vl, crit)
    pi, y = predict(mi, el, 'img')
    tl2 = DataLoader(MetaOnlyDataset(tm, ytr), batch_size=96, shuffle=True)
    vl2, el2 = DataLoader(MetaOnlyDataset(vm, yva), batch_size=96), DataLoader(MetaOnlyDataset(sm, yte), batch_size=96)
    mm = train_best(MetaOnlyModel(len(rc)).to(device), 'meta', EPOCHS_BASE, tl2, vl2, crit)
    pm, y2 = predict(mm, el2, 'meta'); assert (y == y2).all()
    for i in range(len(test_df)):
        base_rows.append({'seed': seed, 'img_id': test_df.loc[i, 'img_id'], 'true_label': int(y[i]),
                          'img_prob_1': float(pi[i, 1]), 'meta_prob_1': float(pm[i, 1])})
    pd.DataFrame(base_rows).to_csv(f'{OUT_DIR}/pad_baseline_predictions_per_sample.csv', index=False)
    del mi, mm; torch.cuda.empty_cache()
base = pd.DataFrame(base_rows)

# =====================================================================
# PART 2: metrics (both ECE conventions), pooled CI, paired tests
# =====================================================================
print('\n========== PART 2: METRICS ==========')
def ece_top_label(y, p1, nb=10):
    pr = (p1 >= 0.5).astype(int); conf = np.where(pr == 1, p1, 1 - p1); e = 0.0
    bins = np.linspace(0, 1, nb + 1)
    for i in range(nb):
        m = (conf >= bins[i]) & ((conf < bins[i + 1]) if i < nb - 1 else (conf <= bins[i + 1]))
        if m.sum() > 0: e += m.mean() * abs((pr[m] == y[m]).mean() - conf[m].mean())
    return e
def ece_cancer_prob(y, p1, nb=10):
    e = 0.0; bins = np.linspace(0, 1, nb + 1)
    for i in range(nb):
        m = (p1 >= bins[i]) & ((p1 < bins[i + 1]) if i < nb - 1 else (p1 <= bins[i + 1]))
        if m.sum() > 0: e += m.mean() * abs(y[m].mean() - p1[m].mean())
    return e
def metrics(y, p1):
    pr = (p1 >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pr, labels=[0, 1]).ravel()
    sens, spec = tp / (tp + fn), tn / (tn + fp)
    return {'AUROC': roc_auc_score(y, p1), 'AUPRC': average_precision_score(y, p1), 'Accuracy': (pr == y).mean(),
            'BalancedAcc': (sens + spec) / 2, 'Sensitivity': sens, 'Specificity': spec, 'F1': f1_score(y, pr),
            'ECE_toplabel': ece_top_label(y, p1), 'ECE_cancerprob': ece_cancer_prob(y, p1)}

allp = pred.merge(base[['seed', 'img_id', 'img_prob_1', 'meta_prob_1']], on=['seed', 'img_id'], how='left')
assert allp['img_prob_1'].notna().all()
MODELS = {'ImageOnly': 'img_prob_1', 'MetaOnly': 'meta_prob_1', 'Fusion': 'fusion_prob_1', 'MetaBlock': 'mb_prob_1'}
rows = []
for seed in SEEDS:
    s = allp[allp['seed'] == seed]
    for nm, col in MODELS.items():
        r = metrics(s['true_label'].values, s[col].values); r.update(model=nm, seed=seed); rows.append(r)
res = pd.DataFrame(rows); res.to_csv(f'{OUT_DIR}/pad_metrics_per_seed.csv', index=False)
cols = ['AUROC', 'AUPRC', 'Accuracy', 'BalancedAcc', 'Sensitivity', 'Specificity', 'F1', 'ECE_toplabel', 'ECE_cancerprob']
print(f'\n===== MEAN ± SD over {len(SEEDS)} runs =====')
summ = pd.DataFrame({m: {c: f'{g[c].mean():.3f} ± {g[c].std():.3f}' for c in cols} for m, g in res.groupby('model')}).T
summ = summ.loc[['ImageOnly', 'MetaOnly', 'Fusion', 'MetaBlock']]
print(summ.to_string()); summ.to_csv(f'{OUT_DIR}/pad_metrics_summary.csv')

print('\n===== POOLED (descriptive) + bootstrap 95% CI of AUROC =====')
rng = np.random.RandomState(0)
for nm, col in MODELS.items():
    y, p = allp['true_label'].values, allp[col].values
    pm_ = metrics(y, p); n = len(y); bs = []
    for _ in range(N_BOOT):
        idx = rng.randint(0, n, n)
        try: bs.append(roc_auc_score(y[idx], p[idx]))
        except Exception: pass
    lo, hi = np.percentile(bs, [2.5, 97.5])
    print(f"{nm:10s} AUROC {pm_['AUROC']:.3f} (95% CI {lo:.3f}-{hi:.3f}) | pooled ECE top-label {pm_['ECE_toplabel']:.3f}, cancer-prob {pm_['ECE_cancerprob']:.3f}")

print('\n===== PAIRED TESTS (per-run Accuracy / AUROC; orientation only) =====')
def get(model, c): return res[res.model == model].sort_values('seed')[c].values
pairs = [('MetaBlock', 'Fusion'), ('Fusion', 'ImageOnly'), ('MetaBlock', 'ImageOnly'), ('Fusion', 'MetaOnly'), ('MetaBlock', 'MetaOnly')]
for a_, b_ in pairs:
    for c in ['Accuracy', 'AUROC']:
        a, b = get(a_, c), get(b_, c)
        try: wp = wilcoxon(a, b)[1]
        except Exception: wp = float('nan')
        print(f'{a_} vs {b_} {c}: mean diff {np.mean(a - b):+.3f}, paired t p={ttest_rel(a, b)[1]:.4f}, Wilcoxon p={wp:.4f}')

# =====================================================================
# PART 3: Multimodal Attribution Analysis on the Fusion models
# =====================================================================
print('\n========== PART 3: ATTRIBUTION ==========')
def spear(a, b): return spearmanr(a, b)[0]
attr_rows, sample_rows = [], []
for seed in SEEDS:
    print(f'\n--- Attribution, seed {seed} ---')
    s = pred[pred['seed'] == seed].reset_index(drop=True)
    tm_df = pd.read_csv(f'{OUT_DIR}/pad_test_meta_seed{seed}.csv').set_index('img_id').loc[s['img_id']]
    mcols = [c for c in tm_df.columns]
    META_DIM = len(mcols)
    labels = s['true_label'].values.astype(int)
    ds = SkinFusionDataset(s[['img_id']], tm_df.reset_index(drop=True), labels, transform)
    loader = DataLoader(ds, batch_size=32, shuffle=False, num_workers=0)

    fusion = FusionModel(META_DIM).to(device); mb = MetaBlock(1536, META_DIM).to(device)
    fusion.load_state_dict(torch.load(f'{OUT_DIR}/pad_fusion_seed{seed}.pth', map_location=device)); fusion.eval()
    mb.load_state_dict(torch.load(f'{OUT_DIR}/pad_metablock_seed{seed}.pth', map_location=device)); mb.eval()
    print('  checkpoints loaded cleanly (all keys matched)')

    P = {'full': [], 'img': [], 'meta': []}; G = []
    with torch.no_grad():
        for img, meta, y in loader:
            img, meta, y = img.to(device), meta.to(device), y.to(device)
            for k, (i_, m_) in {'full': (img, meta), 'img': (img, torch.zeros_like(meta)), 'meta': (torch.zeros_like(img), meta)}.items():
                P[k].append(torch.softmax(fusion(i_, m_), 1).gather(1, y[:, None])[:, 0].cpu())
            G.append(mb.meta_gate(meta).mean(1).cpu())
    pIM, pI, pM = [torch.cat(P[k]).numpy() for k in ['full', 'img', 'meta']]
    gate = torch.cat(G).numpy()
    rI, rM = pIM - pM, pIM - pI                               # ablation-derived reference (Eq. 6)
    p0 = 0.5
    phiI = 0.5 * ((pI - p0) + (pIM - pM)); phiM = 0.5 * ((pM - p0) + (pIM - pI))   # Shapley (Eq. 7)

    # Integrated Gradients on a random subset of test images (fixed per seed)
    rs = np.random.RandomState(seed); sel = np.sort(rs.choice(len(s), size=min(IG_N, len(s)), replace=False))
    sub_loader = DataLoader(torch.utils.data.Subset(ds, sel.tolist()), batch_size=4, shuffle=False, num_workers=0)
    def ig_fraction(model):
        def fwd(img, meta): return torch.softmax(model(img, meta), 1)
        ig = IntegratedGradients(fwd); fr = []
        for img, meta, y in sub_loader:
            img, meta, y = img.to(device), meta.to(device), y.to(device)
            a_i, a_m = ig.attribute((img, meta), baselines=(torch.zeros_like(img), torch.zeros_like(meta)),
                                    target=y, n_steps=IG_STEPS, internal_batch_size=4)
            si, sm_ = a_i.abs().flatten(1).sum(1), a_m.abs().flatten(1).sum(1)
            fr.append((si / (si + sm_ + 1e-12)).detach().cpu()); del a_i, a_m
            if device.type == 'cuda': torch.cuda.empty_cache()
        return torch.cat(fr).numpy()
    FI = ig_fraction(fusion)
    torch.manual_seed(seed)
    rand_model = FusionModel(META_DIM).to(device).eval()
    FI_rand = ig_fraction(rand_model)

    attr_rows.append({
        'seed': seed, 'n_test': len(s), 'n_IG': len(sel),
        'acc_full': float((((pIM >= 0.5)).mean())), 'mean_pIM': pIM.mean(), 'mean_pI': pI.mean(), 'mean_pM': pM.mean(),
        'mean_rI': rI.mean(), 'mean_rM': rM.mean(), 'mean_shap_img': phiI.mean(), 'mean_shap_meta': phiM.mean(),
        'mean_IG_img_fraction': FI.mean(), 'mean_IG_img_fraction_RANDOM': FI_rand.mean(), 'mean_gate': gate.mean(),
        'rho_shapley_vs_rI': spear(phiI, rI), 'rho_IG_vs_rI': spear(FI, rI[sel]), 'rho_gate_vs_rI': spear(gate, rI),
        'rho_IG_trained_vs_random': spear(FI, FI_rand)})
    print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in attr_rows[-1].items()})
    for j in range(len(s)):
        sample_rows.append({'seed': seed, 'img_id': s.loc[j, 'img_id'], 'true_label': labels[j], 'p_full': pIM[j],
                            'p_img_only': pI[j], 'p_meta_only': pM[j], 'rI': rI[j], 'rM': rM[j],
                            'shap_img': phiI[j], 'shap_meta': phiM[j], 'gate_mean': gate[j]})
    pd.DataFrame(sample_rows).to_csv(f'{OUT_DIR}/pad_attribution_per_sample.csv', index=False)
    pd.DataFrame(attr_rows).to_csv(f'{OUT_DIR}/pad_attribution_per_seed.csv', index=False)
    del fusion, mb, rand_model; torch.cuda.empty_cache()

att = pd.DataFrame(attr_rows)
print(f'\n===== ATTRIBUTION SUMMARY (mean ± SD over {len(att)} runs) =====')
for c in att.columns:
    if c in ('seed', 'n_test', 'n_IG'): continue
    print(f'{c:32s} {att[c].mean():.3f} ± {att[c].std():.3f}')
print('\nDONE. Files in', OUT_DIR, ': pad_metrics_summary.csv, pad_metrics_per_seed.csv, pad_attribution_per_seed.csv, pad_attribution_per_sample.csv, pad_baseline_predictions_per_sample.csv')

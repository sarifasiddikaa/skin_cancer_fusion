# Metadata-only logistic regression, patient-grouped 5-fold CV, to show which PAD-UFES-20 variables leak the label.
import pandas as pd, numpy as np, sys
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
m = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else 'metadata.csv')
m['y'] = m['diagnostic'].isin(['BCC', 'SCC', 'MEL']).astype(int); m['patient_id'] = m['patient_id'].astype(str)
drop = {'patient_id', 'lesion_id', 'diagnostic', 'img_id', 'y'}
q_block = ['smoke','drink','background_father','background_mother','pesticide','gender','skin_cancer_history','cancer_history',
           'has_piped_water','has_sewage_system','fitspatrick','diameter_1','diameter_2']
sets = {'ALL variables (incl. biopsed, questionnaire block, grew/changed)': [c for c in m.columns if c not in drop],
        'without biopsed': [c for c in m.columns if c not in drop | {'biopsed'}],
        'without biopsed + questionnaire block (keeps grew/changed)': [c for c in m.columns if c not in drop | {'biopsed'} | set(q_block)],
        'age + region only': ['age', 'region'],
        'CHOSEN: age, region, itch, hurt, bleed, elevation': ['age', 'region', 'itch', 'hurt', 'bleed', 'elevation']}
def X_of(cols):
    num = [c for c in cols if pd.api.types.is_numeric_dtype(m[c]) and c not in ('smoke',) and m[c].dtype != bool and c != 'biopsed']
    cat = [c for c in cols if c not in num]
    Xn = m[num].copy(); Xn = Xn.fillna(Xn.median()) if len(num) else Xn
    return pd.concat([Xn, pd.get_dummies(m[cat].astype(str), dtype=float)], axis=1)
for name, cols in sets.items():
    X = X_of(cols).values.astype(float); X = (X - X.mean(0)) / (X.std(0) + 1e-9); aucs = []
    for seed in range(1, 6):
        cv = StratifiedGroupKFold(5, shuffle=True, random_state=seed); p = np.zeros(len(m))
        for tr, te in cv.split(X, m['y'], m['patient_id']):
            p[te] = LogisticRegression(max_iter=2000).fit(X[tr], m['y'][tr]).predict_proba(X[te])[:, 1]
        aucs.append(roc_auc_score(m['y'], p))
    print(f'{name:70s} AUROC {np.mean(aucs):.3f} ± {np.std(aucs, ddof=1):.3f}')
print('\nImages with the questionnaire block missing (smoke NaN):', int(m['smoke'].isna().sum()),
      '| cancer among them:', int(m.loc[m['smoke'].isna(), 'y'].sum()))
print('Cancers biopsed:', int(m.loc[m.y == 1, 'biopsed'].sum()), 'of', int(m.y.sum()), '| non-cancers biopsed:', int(m.loc[m.y == 0, 'biopsed'].sum()), 'of', int((m.y == 0).sum()))
for c in ['grew', 'changed']:
    print(c, 'UNK -> cancer fraction %.2f (n=%d)' % (m.loc[m[c].astype(str) == 'UNK', 'y'].mean(), (m[c].astype(str) == 'UNK').sum()))

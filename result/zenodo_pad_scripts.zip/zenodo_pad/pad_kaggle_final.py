# =====================================================================
# 07_pad_ufes_train_fusion_metablock.py
# Second-dataset replication on PAD-UFES-20 (binary: skin cancer vs non-cancer)
# Same implementation as 01_train_fusion_metablock.py (ISIC-DICM-17K).
# ONLY the data-loading / label / metadata-column parts differ.
# Unchanged: models, optimizer, lr, weight decay, batch size, loss, AMP,
#            augmentation, nested StratifiedGroupKFold, best-val-accuracy
#            checkpoint, seeds 1-5, Fusion 15 epochs, MetaBlock 18 epochs.
# =====================================================================
import os, json, numpy as np, pandas as pd, torch, torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms
import torchvision.models as models
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from torch.cuda.amp import autocast, GradScaler

# ---------------- CONFIG (edit only this block) ----------------
INPUT_ROOT = '/kaggle/input'
OUT_DIR    = '/kaggle/working'
QUICK      = False     # False = full run used for the paper (seeds 1-5; Fusion 15 epochs, MetaBlock 18). True = smoke test (1 seed, 2 epochs).
PRETRAINED = True
SEEDS      = [1] if QUICK else [1, 2, 3, 4, 5]
EPOCHS_FUSION, EPOCHS_MB = (2, 2) if QUICK else (15, 18)

# Pre-specified, leakage-safe metadata (decided BEFORE looking at any results).
# Excluded on purpose:
#   biopsed                 -> every cancer was biopsied (label leakage)
#   questionnaire block     -> gender, fitspatrick, diameter_1/2, smoke, drink, pesticide,
#                              skin_cancer_history, cancer_history, background_*, piped water,
#                              sewage: all missing in 804 images that are 100% non-cancer
#                              (missingness itself would reveal the label)
#   grew, changed           -> 'UNK' answers occur almost only in cancer images (label leakage)
cat_cols     = ['region', 'itch', 'hurt', 'bleed', 'elevation']
numeric_cols = ['age']
# ----------------------------------------------------------------

def find_file(root, name):
    for d, _, fs in os.walk(root):
        if name in fs:
            return os.path.join(d, name)
    raise FileNotFoundError(name)

META_CSV = find_file(INPUT_ROOT, 'metadata.csv')
print('metadata:', META_CSV)
df = pd.read_csv(META_CSV)
df['class'] = df['diagnostic'].isin(['BCC', 'SCC', 'MEL']).astype(int)   # 1 = cancer
df['patient_id'] = df['patient_id'].astype(str)                          # present for all images

print('Indexing images...')
IMAGE_LOOKUP = {}
for d, _, fs in os.walk(INPUT_ROOT):
    for f in fs:
        if f.lower().endswith(('.png', '.jpg', '.jpeg')):
            IMAGE_LOOKUP[f] = os.path.join(d, f)

corrupted = []
for i, row in df.iterrows():
    p = IMAGE_LOOKUP.get(row['img_id'])
    if p is None:
        corrupted.append(row['img_id']); continue
    try:
        Image.open(p).convert('RGB')
    except Exception:
        corrupted.append(row['img_id'])
full_subset = df[~df['img_id'].isin(corrupted)].reset_index(drop=True)
print('Usable total:', len(full_subset), '| Corrupted/missing:', len(corrupted))
print('Class counts (1=cancer):', full_subset['class'].value_counts().to_dict())

def encode_metadata(df_in, medians, reference_columns=None):
    df_cat = pd.get_dummies(df_in[cat_cols].astype(str))
    df_num = df_in[numeric_cols].fillna(medians)
    df_encoded = pd.concat([df_num, df_cat], axis=1)
    if reference_columns is not None:
        df_encoded = df_encoded.reindex(columns=reference_columns, fill_value=0)
    return df_encoded

class SkinFusionDataset(Dataset):
    def __init__(self, df, meta_features, labels, transform=None):
        self.df = df.reset_index(drop=True)
        self.meta_features = meta_features.reset_index(drop=True)
        self.labels = labels
        self.transform = transform
        self.image_cache = {}
        self.resize = transforms.Resize((224, 224))
    def __len__(self): return len(self.df)
    def __getitem__(self, idx):
        img_name = self.df.loc[idx, 'img_id']
        if img_name not in self.image_cache:
            raw = Image.open(IMAGE_LOOKUP[img_name]).convert('RGB')
            self.image_cache[img_name] = self.resize(raw)
        image = self.image_cache[img_name].copy()
        if self.transform: image = self.transform(image)
        meta = torch.tensor(self.meta_features.iloc[idx].values.astype('float32'))
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return image, meta, label

transform = transforms.Compose([transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])
train_transform = transforms.Compose([transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(20), transforms.ColorJitter(brightness=0.2, contrast=0.2), transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.backends.cudnn.benchmark = True
print('Device:', device)

def train_one_epoch(model, loader, criterion, optimizer, device, scaler):
    model.train()
    for images, metas, labels in loader:
        images, metas, labels = images.to(device), metas.to(device), labels.to(device)
        optimizer.zero_grad()
        with autocast():
            outputs = model(images, metas)
            loss = criterion(outputs, labels)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

def evaluate(model, loader, device):
    model.eval(); correct, total = 0, 0
    with torch.no_grad():
        for images, metas, labels in loader:
            images, metas, labels = images.to(device), metas.to(device), labels.to(device)
            with autocast():
                outputs = model(images, metas)
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item(); total += labels.size(0)
    return correct / total

FREEZE_PATTERN = ['0.8.']

def _backbone():
    eff = models.efficientnet_b3(weights='IMAGENET1K_V1' if PRETRAINED else None)
    return nn.Sequential(eff.features, eff.avgpool)

class FusionModel(nn.Module):
    def __init__(self, meta_input_dim, num_classes):
        super().__init__()
        self.image_branch = _backbone()
        for name, p in self.image_branch.named_parameters():
            p.requires_grad = any(name.startswith(pat) for pat in FREEZE_PATTERN)
        self.meta_branch = nn.Sequential(nn.Linear(meta_input_dim, 64), nn.ReLU(), nn.Linear(64, 32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(1536 + 32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        i = self.image_branch(image).flatten(1)
        m = self.meta_branch(meta)
        return self.classifier(torch.cat([i, m], dim=1))

class MetaBlock(nn.Module):
    def __init__(self, image_feat_dim, meta_input_dim, num_classes):
        super().__init__()
        self.image_branch = _backbone()
        for name, p in self.image_branch.named_parameters():
            p.requires_grad = any(name.startswith(pat) for pat in FREEZE_PATTERN)
        self.meta_gate = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Sigmoid())
        self.meta_bias = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Tanh())
        self.classifier = nn.Sequential(nn.Linear(image_feat_dim, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        img_feat = self.image_branch(image).flatten(1)
        gate = self.meta_gate(meta); bias = self.meta_bias(meta)
        return self.classifier(img_feat * gate + bias)

def get_probs(model, loader, device):
    model.eval(); all_probs = []
    with torch.no_grad():
        for images, metas, labels in loader:
            images, metas = images.to(device), metas.to(device)
            with autocast():
                out = torch.softmax(model(images, metas), dim=1)
            all_probs.append(out.float().cpu())
    return torch.cat(all_probs)

stage_subset = full_subset.copy()
if QUICK:
    stage_subset = stage_subset.sample(frac=0.3, random_state=1).reset_index(drop=True)

all_predictions, stage_results, split_rows = [], [], []

for seed in SEEDS:
    print(f'\n--- FINAL Seed {seed} ---')
    torch.manual_seed(seed); np.random.seed(seed); torch.cuda.manual_seed_all(seed)

    sgkf1 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    trainval_idx, test_idx = next(sgkf1.split(stage_subset, stage_subset['class'], groups=stage_subset['patient_id']))
    trainval_df = stage_subset.iloc[trainval_idx].reset_index(drop=True)
    test_df = stage_subset.iloc[test_idx].reset_index(drop=True)
    sgkf2 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    train_idx, val_idx = next(sgkf2.split(trainval_df, trainval_df['class'], groups=trainval_df['patient_id']))
    train_df = trainval_df.iloc[train_idx].reset_index(drop=True)
    val_df = trainval_df.iloc[val_idx].reset_index(drop=True)

    overlap = len(set(train_df['patient_id']) & set(test_df['patient_id']))
    overlap2 = len(set(val_df['patient_id']) & set(test_df['patient_id']))
    print('Patient overlap train/test, val/test (must be 0):', overlap, overlap2)
    print('n train/val/test:', len(train_df), len(val_df), len(test_df),
          '| cancer fraction test: %.3f' % test_df['class'].mean())
    if overlap > 0 or overlap2 > 0:
        print('WARNING: overlap, skipping seed'); continue

    for d_, nm in [(train_df, 'train'), (val_df, 'val'), (test_df, 'test')]:
        for _, r in d_[['img_id', 'patient_id']].iterrows():
            split_rows.append({'seed': seed, 'split': nm, 'img_id': r['img_id'], 'patient_id': r['patient_id']})
        for col in cat_cols: d_[col] = d_[col].astype(str)

    train_medians = train_df[numeric_cols].median()
    train_meta = encode_metadata(train_df, train_medians)
    ref_cols = train_meta.columns
    val_meta = encode_metadata(val_df, train_medians, ref_cols)
    test_meta = encode_metadata(test_df, train_medians, ref_cols)
    META_DIM = len(ref_cols)
    print('META_DIM:', META_DIM)

    le = LabelEncoder(); le.fit(train_df['class'])
    train_labels = le.transform(train_df['class'])
    val_labels = le.transform(val_df['class'])
    test_labels = le.transform(test_df['class'])

    train_ds = SkinFusionDataset(train_df, train_meta, train_labels, train_transform)
    val_ds = SkinFusionDataset(val_df, val_meta, val_labels, transform)
    test_ds = SkinFusionDataset(test_df, test_meta, test_labels, transform)
    train_loader = DataLoader(train_ds, batch_size=96, shuffle=True, num_workers=0, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=96, shuffle=False, num_workers=0, pin_memory=True)
    test_loader = DataLoader(test_ds, batch_size=96, shuffle=False, num_workers=0, pin_memory=True)

    class_weights = torch.tensor(compute_class_weight('balanced', classes=np.unique(train_labels), y=train_labels), dtype=torch.float32).to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    def train_best(model_cls, epochs, **kwargs):
        m = model_cls(**kwargs).to(device)
        opt = torch.optim.Adam(filter(lambda p: p.requires_grad, m.parameters()), lr=1e-4, weight_decay=1e-3)
        scaler = GradScaler()
        best_val, best_state = -1, None
        for ep in range(epochs):
            train_one_epoch(m, train_loader, criterion, opt, device, scaler)
            val_acc = evaluate(m, val_loader, device)
            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.clone() for k, v in m.state_dict().items()}
        m.load_state_dict(best_state)
        return evaluate(m, test_loader, device), m

    fusion_acc, fusion_model = train_best(FusionModel, EPOCHS_FUSION, meta_input_dim=META_DIM, num_classes=2)
    mb_acc, mb_model = train_best(MetaBlock, EPOCHS_MB, image_feat_dim=1536, meta_input_dim=META_DIM, num_classes=2)
    print(f'Fusion: {fusion_acc:.4f} | MetaBlock: {mb_acc:.4f}')
    stage_results.append({'seed': seed, 'fusion_acc': fusion_acc, 'mb_acc': mb_acc})

    fusion_probs = get_probs(fusion_model, test_loader, device)
    mb_probs = get_probs(mb_model, test_loader, device)
    torch.save(fusion_model.state_dict(), f'{OUT_DIR}/pad_fusion_seed{seed}.pth')
    torch.save(mb_model.state_dict(), f'{OUT_DIR}/pad_metablock_seed{seed}.pth')
    test_meta.assign(img_id=test_df['img_id'].values).to_csv(f'{OUT_DIR}/pad_test_meta_seed{seed}.csv', index=False)
    for i in range(len(test_df)):
        all_predictions.append({
            'seed': seed, 'img_id': test_df.iloc[i]['img_id'], 'patient_id': test_df.iloc[i]['patient_id'],
            'true_label': int(test_labels[i]),
            'fusion_prob_0': fusion_probs[i, 0].item(), 'fusion_prob_1': fusion_probs[i, 1].item(),
            'mb_prob_0': mb_probs[i, 0].item(), 'mb_prob_1': mb_probs[i, 1].item()})

results_df = pd.DataFrame(stage_results)
print('\nSUMMARY:\n', results_df)
if len(results_df): print(results_df[['fusion_acc', 'mb_acc']].agg(['mean', 'std']))
pd.DataFrame(all_predictions).to_csv(f'{OUT_DIR}/pad_final_predictions_per_sample.csv', index=False)
pd.DataFrame(split_rows).to_csv(f'{OUT_DIR}/pad_split_assignments.csv', index=False)
json.dump({'cat_cols': cat_cols, 'numeric_cols': numeric_cols, 'meta_cols': list(ref_cols)},
          open(f'{OUT_DIR}/pad_meta_config.json', 'w'))
print('Saved predictions, checkpoints, split assignments, encoded test metadata.')

# ===== UNIMODAL BASELINES: image-only and metadata-only (same splits/seeds/settings as Fusion) =====
import pandas as pd, numpy as np, os, torch, torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms
import torchvision.models as models
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, f1_score
from scipy.stats import ttest_rel, wilcoxon
from torch.cuda.amp import autocast, GradScaler

IMAGE_FOLDER = '/kaggle/input/datasets/iamtrina/isic-images-full/images_full'
TRAIN_META = '/kaggle/input/datasets/sarifasiddikatrina/isic-dicm/train-set-metadata.csv'
PRED_CSV = '/kaggle/input/datasets/sarifasiddikaa/final-results-15k/final_predictions_per_sample.csv'  # Fusion/MetaBlock predictions (for split check + comparison)
EPOCHS_IMG, EPOCHS_META = 15, 15

df = pd.read_csv(TRAIN_META)
mel_full = df[df['class']==1]
non_mel_full = df[df['class']==0].sample(n=len(mel_full), random_state=42)
full_subset = pd.concat([mel_full, non_mel_full]).reset_index(drop=True)
full_subset['patient_id'] = full_subset['patient_id'].astype(str)
full_subset.loc[full_subset['patient_id']=='nan','patient_id'] = 'unknown_' + full_subset.index[full_subset['patient_id']=='nan'].astype(str)
corrupted = []
for i, row in full_subset.iterrows():
    p = f"{IMAGE_FOLDER}/{row['isic_id']}.jpg"
    if not os.path.exists(p): corrupted.append(row['isic_id']); continue
    try: Image.open(p).convert('RGB')
    except Exception: corrupted.append(row['isic_id'])
full_subset = full_subset[~full_subset['isic_id'].isin(corrupted)].reset_index(drop=True)
print("Usable total:", len(full_subset), "| Corrupted/missing:", len(corrupted))

cat_cols = ['sex', 'anatom_site_general', 'personal_hx_mm', 'family_hx_mm']
numeric_cols = ['age_approx', 'clin_size_long_diam_mm']
def encode_metadata(df_in, medians, reference_columns=None):
    df_cat = pd.get_dummies(df_in[cat_cols].astype(str))
    df_num = df_in[numeric_cols].fillna(medians)
    df_encoded = pd.concat([df_num, df_cat], axis=1)
    if reference_columns is not None:
        df_encoded = df_encoded.reindex(columns=reference_columns, fill_value=0)
    return df_encoded

class SkinFusionDataset(Dataset):
    def __init__(self, df, meta_features, labels, folder, transform=None):
        self.df = df.reset_index(drop=True); self.meta_features = meta_features.reset_index(drop=True)
        self.labels = labels; self.transform = transform
        self.image_lookup = {f: os.path.join(folder, f) for f in os.listdir(folder)}
        self.image_cache = {}; self.resize = transforms.Resize((224,224))
    def __len__(self): return len(self.df)
    def __getitem__(self, idx):
        img_name = self.df.loc[idx, 'img_id']
        if img_name not in self.image_cache:
            self.image_cache[img_name] = self.resize(Image.open(self.image_lookup[img_name]).convert('RGB'))
        image = self.image_cache[img_name].copy()
        if self.transform: image = self.transform(image)
        meta = torch.tensor(self.meta_features.iloc[idx].values.astype('float32'))
        return image, meta, torch.tensor(self.labels[idx], dtype=torch.long)

class MetaOnlyDataset(Dataset):
    def __init__(self, meta_features, labels):
        self.m = torch.tensor(meta_features.values.astype('float32')); self.y = torch.tensor(labels, dtype=torch.long)
    def __len__(self): return len(self.y)
    def __getitem__(self, i): return self.m[i], self.y[i]

transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])])
train_transform = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.2, contrast=0.2), transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])])
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.backends.cudnn.benchmark = True
FREEZE_PATTERN = ['0.8.']

class ImageOnlyModel(nn.Module):   # same image branch + classifier head as MetaBlock, no metadata
    def __init__(self, num_classes=2):
        super().__init__()
        eff = models.efficientnet_b3(weights='IMAGENET1K_V1')
        self.image_branch = nn.Sequential(eff.features, eff.avgpool)
        for name, p in self.image_branch.named_parameters():
            p.requires_grad = any(name.startswith(pat) for pat in FREEZE_PATTERN)
        self.classifier = nn.Sequential(nn.Linear(1536, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image): return self.classifier(self.image_branch(image).flatten(1))

class MetaOnlyModel(nn.Module):    # same metadata branch as Fusion + same head, no image
    def __init__(self, meta_dim, num_classes=2):
        super().__init__()
        self.meta_branch = nn.Sequential(nn.Linear(meta_dim, 64), nn.ReLU(), nn.Linear(64,32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, meta): return self.classifier(self.meta_branch(meta))

def run_epoch(model, loader, mode, criterion, opt, scaler):
    model.train()
    for batch in loader:
        if mode=='meta': x, y = batch[0].to(device), batch[1].to(device)
        else: x, y = batch[0].to(device), batch[2].to(device)
        opt.zero_grad()
        with autocast(): loss = criterion(model(x), y)
        scaler.scale(loss).backward(); scaler.step(opt); scaler.update()

def predict(model, loader, mode):
    model.eval(); probs, ys = [], []
    with torch.no_grad():
        for batch in loader:
            if mode=='meta': x, y = batch[0].to(device), batch[1]
            else: x, y = batch[0].to(device), batch[2]
            with autocast(): p = torch.softmax(model(x), 1)
            probs.append(p.float().cpu()); ys.append(y)
    return torch.cat(probs).numpy(), torch.cat(ys).numpy()

def train_best(model, mode, epochs, tl, vl, criterion):
    opt = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4, weight_decay=1e-3)
    scaler = GradScaler(); best, state = 0, None
    for ep in range(epochs):
        run_epoch(model, tl, mode, criterion, opt, scaler)
        pr, y = predict(model, vl, mode); acc = (pr.argmax(1)==y).mean()
        if acc > best: best, state = acc, {k: v.clone() for k, v in model.state_dict().items()}
    model.load_state_dict(state); return model

def metrics(y, p1):
    pred = (p1>=0.5).astype(int); conf = np.where(pred==1, p1, 1-p1)
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel(); sens, spec = tp/(tp+fn), tn/(tn+fp)
    bins = np.linspace(0,1,11); ece = 0
    for i in range(10):
        m = (conf>=bins[i])&(conf<bins[i+1])
        if m.sum()>0: ece += m.mean()*abs((pred[m]==y[m]).mean()-conf[m].mean())
    return {'AUROC': roc_auc_score(y,p1), 'AUPRC': average_precision_score(y,p1), 'Accuracy': (pred==y).mean(),
            'BalancedAcc': (sens+spec)/2, 'Sensitivity': sens, 'Specificity': spec, 'F1': f1_score(y,pred), 'ECE': ece}

pred_ref = pd.read_csv(PRED_CSV)
rows, all_pred = [], []
for seed in range(1, 6):
    print(f"\n=== Seed {seed} ===")
    torch.manual_seed(seed); np.random.seed(seed); torch.cuda.manual_seed_all(seed)
    s1 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    tv_idx, te_idx = next(s1.split(full_subset, full_subset['class'], groups=full_subset['patient_id']))
    tv = full_subset.iloc[tv_idx].reset_index(drop=True); test_df = full_subset.iloc[te_idx].reset_index(drop=True)
    s2 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    tr_idx, va_idx = next(s2.split(tv, tv['class'], groups=tv['patient_id']))
    train_df = tv.iloc[tr_idx].reset_index(drop=True); val_df = tv.iloc[va_idx].reset_index(drop=True)
    assert len(set(train_df['patient_id']) & set(test_df['patient_id'])) == 0
    # SPLIT CHECK: test set must be identical to the Fusion/MetaBlock test set of this seed
    ref_ids = set(pred_ref[pred_ref['seed']==seed]['isic_id'])
    print("Test set identical to Fusion/MetaBlock test set:", set(test_df['isic_id'])==ref_ids, f"({len(ref_ids)} images)")
    for d in [train_df, val_df, test_df]:
        d['img_id'] = d['isic_id']+'.jpg'
        for c in cat_cols: d[c] = d[c].astype(str)
    med = train_df[numeric_cols].median()
    tm = encode_metadata(train_df, med); rc = tm.columns
    vm = encode_metadata(val_df, med, rc); sm = encode_metadata(test_df, med, rc)
    le = LabelEncoder(); le.fit(train_df['class'])
    ytr, yva, yte = le.transform(train_df['class']), le.transform(val_df['class']), le.transform(test_df['class'])
    cw = torch.tensor(compute_class_weight('balanced', classes=np.unique(ytr), y=ytr), dtype=torch.float32).to(device)
    crit = nn.CrossEntropyLoss(weight=cw)

    # image-only
    tl = DataLoader(SkinFusionDataset(train_df, tm, ytr, IMAGE_FOLDER, train_transform), batch_size=96, shuffle=True, num_workers=0, pin_memory=True)
    vl = DataLoader(SkinFusionDataset(val_df, vm, yva, IMAGE_FOLDER, transform), batch_size=96, num_workers=0, pin_memory=True)
    el = DataLoader(SkinFusionDataset(test_df, sm, yte, IMAGE_FOLDER, transform), batch_size=96, num_workers=0, pin_memory=True)
    mi = train_best(ImageOnlyModel().to(device), 'img', EPOCHS_IMG, tl, vl, crit)
    pi, y = predict(mi, el, 'img')
    # metadata-only
    tl2 = DataLoader(MetaOnlyDataset(tm, ytr), batch_size=96, shuffle=True)
    vl2 = DataLoader(MetaOnlyDataset(vm, yva), batch_size=96); el2 = DataLoader(MetaOnlyDataset(sm, yte), batch_size=96)
    mm = train_best(MetaOnlyModel(len(rc)).to(device), 'meta', EPOCHS_META, tl2, vl2, crit)
    pm, y2 = predict(mm, el2, 'meta'); assert (y==y2).all()
    for name, p in [('ImageOnly', pi[:,1]), ('MetaOnly', pm[:,1])]:
        r = metrics(y, p); r.update(model=name, seed=seed); rows.append(r); print(name, {k: round(v,4) for k,v in r.items() if k not in ('model','seed')})
    # Fusion / MetaBlock from existing predictions (same test images)
    sd = pred_ref[pred_ref['seed']==seed]
    for name, col in [('Fusion','fusion_prob_1'), ('MetaBlock','mb_prob_1')]:
        r = metrics(sd['true_label'].values, sd[col].values); r.update(model=name, seed=seed); rows.append(r)
    for i in range(len(test_df)):
        all_pred.append({'seed': seed, 'isic_id': test_df.loc[i,'isic_id'], 'true_label': int(y[i]),
                         'img_prob_1': pi[i,1], 'meta_prob_1': pm[i,1]})

res = pd.DataFrame(rows); res.to_csv('/kaggle/working/baseline_per_seed.csv', index=False)
pd.DataFrame(all_pred).to_csv('/kaggle/working/baseline_predictions_per_sample.csv', index=False)
cols = ['AUROC','AUPRC','Accuracy','BalancedAcc','Sensitivity','Specificity','F1','ECE']
print("\n===== MEAN +- SD over 5 runs =====")
summ = {m: {c: f"{g[c].mean():.3f} ± {g[c].std():.3f}" for c in cols} for m, g in res.groupby('model')}
print(pd.DataFrame(summ).T.loc[['ImageOnly','MetaOnly','Fusion','MetaBlock']])
print("\n===== PAIRED TESTS on accuracy and AUROC (n=5 runs) =====")
for other in ['ImageOnly','MetaOnly']:
    for ref in ['Fusion','MetaBlock']:
        for c in ['Accuracy','AUROC']:
            a = res[res.model==ref].sort_values('seed')[c].values; b = res[res.model==other].sort_values('seed')[c].values
            print(f"{ref} vs {other} {c}: mean diff {np.mean(a-b):+.3f}, paired t p={ttest_rel(a,b)[1]:.4f}, Wilcoxon p={wilcoxon(a,b)[1]:.4f}")
print("\nDONE. Download baseline_per_seed.csv, baseline_predictions_per_sample.csv and paste the two tables above.")

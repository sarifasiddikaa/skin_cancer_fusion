
#### CELL 0
# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# Use the kagglehub client library to attach Kaggle resources like competitions, datasets, and models to your session
# Learn more about kagglehub: https://github.com/Kaggle/kagglehub/blob/main/README.md

import kagglehub
# kagglehub.dataset_download('<owner>/<dataset-slug>')

#### CELL 1
!pip install captum --quiet

#### CELL 2
import os, numpy as np, pandas as pd, torch, torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms
import torchvision.models as models
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, f1_score
from scipy.stats import ttest_rel, wilcoxon, spearmanr
from captum.attr import IntegratedGradients

PRED_CSV = '/kaggle/input/datasets/sarifasiddikaa/final-results-15k/final_predictions_per_sample.csv'
CKPT_DIR = '/kaggle/input/datasets/sarifasiddikaa/final-results-15k'
IMAGE_FOLDER = '/kaggle/input/datasets/iamtrina/isic-images-full/images_full'
META_CSVS = [
    '/kaggle/input/datasets/sarifasiddikatrina/isic-dicm/train-set-metadata.csv',
    '/kaggle/input/datasets/sarifasiddikatrina/isic-dicm/valid-set-metadata.csv',
]
cat_cols = ['sex', 'anatom_site_general', 'personal_hx_mm', 'family_hx_mm']
numeric_cols = ['age_approx', 'clin_size_long_diam_mm']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

pred_df = pd.read_csv(PRED_CSV)

# =====================================================================
# PART 1 (checklist item 2 & 3): FULL METRICS + PAIRED STATS
# =====================================================================
def compute_metrics(df, prob_col):
    y_true = df['true_label'].values
    y_prob = df[prob_col].values
    y_pred = (y_prob >= 0.5).astype(int)
    auroc = roc_auc_score(y_true, y_prob)
    auprc = average_precision_score(y_true, y_prob)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    sensitivity = tp / (tp + fn)
    specificity = tn / (tn + fp)
    f1 = f1_score(y_true, y_pred)
    balanced_acc = (sensitivity + specificity) / 2
    bins = np.linspace(0, 1, 11)
    ece = 0
    for i in range(10):
        mask = (y_prob >= bins[i]) & (y_prob < bins[i+1])
        if mask.sum() > 0:
            bin_acc = (y_pred[mask] == y_true[mask]).mean()
            bin_conf = y_prob[mask].mean()
            ece += (mask.sum() / len(y_prob)) * abs(bin_acc - bin_conf)
    return {'AUROC': auroc, 'AUPRC': auprc, 'Sensitivity': sensitivity,
            'Specificity': specificity, 'F1': f1, 'BalancedAcc': balanced_acc, 'ECE': ece}

def bootstrap_ci(df, prob_col, metric_fn, n_boot=1000, seed=0):
    rng = np.random.RandomState(seed)
    vals, n = [], len(df)
    for _ in range(n_boot):
        idx = rng.randint(0, n, n)
        sample = df.iloc[idx]
        try:
            vals.append(metric_fn(sample, prob_col))
        except Exception:
            continue
    lo, hi = np.percentile(vals, [2.5, 97.5])
    return np.mean(vals), lo, hi

print("========== PART 1: FULL METRICS (checklist item 2) ==========")
print("\n===== PER-SEED METRICS =====")
fusion_accs, mb_accs = [], []
for seed in sorted(pred_df['seed'].unique()):
    seed_df = pred_df[pred_df['seed'] == seed]
    fusion_m = compute_metrics(seed_df, 'fusion_prob_1')
    mb_m = compute_metrics(seed_df, 'mb_prob_1')
    print(f"\nSeed {seed}:")
    print(f"  Fusion:    {fusion_m}")
    print(f"  MetaBlock: {mb_m}")
    fusion_accs.append((seed_df['fusion_prob_1'] >= 0.5).astype(int).eq(seed_df['true_label']).mean())
    mb_accs.append((seed_df['mb_prob_1'] >= 0.5).astype(int).eq(seed_df['true_label']).mean())

print("\n===== POOLED METRICS =====")
print("Fusion:   ", compute_metrics(pred_df, 'fusion_prob_1'))
print("MetaBlock:", compute_metrics(pred_df, 'mb_prob_1'))

print("\n===== 95% CI (bootstrap, pooled AUROC) =====")
for name, col in [('Fusion', 'fusion_prob_1'), ('MetaBlock', 'mb_prob_1')]:
    mean_auc, lo, hi = bootstrap_ci(pred_df, col, lambda d, c: roc_auc_score(d['true_label'], d[c]))
    print(f"{name} AUROC: {mean_auc:.4f} (95% CI {lo:.4f}-{hi:.4f})")

print("\n========== PART 2: PAIRED STATISTICAL TEST (checklist item 3) ==========")
print("Fusion accs:   ", [f"{a:.4f}" for a in fusion_accs])
print("MetaBlock accs:", [f"{a:.4f}" for a in mb_accs])
t_stat, t_p = ttest_rel(mb_accs, fusion_accs)
print(f"\nPaired t-test: t={t_stat:.4f}, p={t_p:.4f}")
try:
    w_stat, w_p = wilcoxon(mb_accs, fusion_accs)
    print(f"Wilcoxon signed-rank: W={w_stat:.4f}, p={w_p:.4f}")
except Exception as e:
    print("Wilcoxon not applicable:", e)
print("\nNote: n=5 seeds is small; p-values are indicative, not strongly conclusive.")

# =====================================================================
# PART 3 (checklist item 4): FULL XAI RE-RUN (ablation/Shapley/IG/gate)
# =====================================================================
print("\n\n========== PART 3: XAI RE-RUN (checklist item 4) ==========")

meta_full = pd.concat([pd.read_csv(f) for f in META_CSVS], ignore_index=True).drop_duplicates('isic_id')
for c in cat_cols:
    meta_full[c] = meta_full[c].astype(str)

ref_dummy = pd.get_dummies(meta_full[cat_cols].astype(str))
REF_COLS = ref_dummy.columns
META_DIM = len(REF_COLS) + len(numeric_cols)
global_medians = meta_full[numeric_cols].median()

meta_all = meta_full[meta_full['isic_id'].isin(pred_df['isic_id'])].reset_index(drop=True)

meta_all['img_id'] = meta_all['isic_id'] + '.jpg'
_cat_encoded = pd.get_dummies(meta_all[cat_cols].astype(str)).reindex(columns=REF_COLS, fill_value=0)
_num_filled = meta_all[numeric_cols].fillna(global_medians)
_encoded_matrix = np.concatenate([_num_filled.values, _cat_encoded.values], axis=1).astype('float32')
meta_all_reset = meta_all.reset_index(drop=True)
encoded_lookup = {iid: _encoded_matrix[i] for i, iid in enumerate(meta_all_reset['isic_id'])}
meta_lookup = meta_all.set_index('isic_id')

def encode_row(iid):
    return encoded_lookup[iid]

transform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

class XAIDataset(Dataset):
    def __init__(self, isic_ids, labels):
        self.isic_ids = isic_ids
        self.labels = labels
    def __len__(self): return len(self.isic_ids)
    def __getitem__(self, idx):
        iid = self.isic_ids[idx]
        row = meta_lookup.loc[iid]
        img = Image.open(os.path.join(IMAGE_FOLDER, row['img_id'])).convert('RGB')
        img = transform(img)
        meta = torch.tensor(encode_row(iid))
        label = torch.tensor(int(self.labels[idx]), dtype=torch.long)
        return img, meta, label

class FusionModel(nn.Module):
    def __init__(self, meta_dim, num_classes=2):
        super().__init__()
        eff = models.efficientnet_b3(weights=None)
        self.image_branch = nn.Sequential(eff.features, eff.avgpool)
        self.meta_branch = nn.Sequential(nn.Linear(meta_dim, 64), nn.ReLU(), nn.Linear(64, 32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(1536 + 32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, img, meta):
        i = self.image_branch(img).flatten(1)
        m = self.meta_branch(meta)
        return self.classifier(torch.cat([i, m], dim=1))

class MetaBlockModel(nn.Module):
    def __init__(self, meta_dim, num_classes=2):
        super().__init__()
        eff = models.efficientnet_b3(weights=None)
        self.image_branch = nn.Sequential(eff.features, eff.avgpool)
        self.meta_gate = nn.Sequential(nn.Linear(meta_dim, 1536))
        self.meta_bias = nn.Sequential(nn.Linear(meta_dim, 1536))
        self.classifier = nn.Sequential(nn.Linear(1536, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, img, meta):
        i = self.image_branch(img).flatten(1)
        gate = torch.sigmoid(self.meta_gate(meta))
        bias = torch.tanh(self.meta_bias(meta))
        modulated = i * gate + bias
        return self.classifier(modulated), gate

def load_model(cls, path, meta_dim, name=""):
    model = cls(meta_dim).to(device)
    sd = torch.load(path, map_location=device)
    result = model.load_state_dict(sd, strict=False)
    if result.missing_keys or result.unexpected_keys:
        print(f"  [WARNING] {name} checkpoint mismatch! Model class does NOT match training script.")
        print(f"  Missing keys (stayed randomly initialized): {result.missing_keys}")
        print(f"  Unexpected keys (ignored from checkpoint): {result.unexpected_keys}")
        print(f"  -> Results below for {name} may be INVALID. Send exact training model class if this appears.")
    else:
        print(f"  {name} checkpoint loaded cleanly (all keys matched).")
    model.eval()
    return model

def batch_accuracy(model, loader, zero_img=False, zero_meta=False, is_metablock=False):
    correct, total = 0, 0
    for img, meta, label in loader:
        img, meta, label = img.to(device), meta.to(device), label.to(device)
        if zero_img: img = torch.zeros_like(img)
        if zero_meta: meta = torch.zeros_like(meta)
        with torch.no_grad():
            out = model(img, meta)
            if is_metablock: out = out[0]
        pred = out.argmax(1)
        correct += (pred == label).sum().item()
        total += label.size(0)
    return correct / total

def ig_attributions(model, loader, is_metablock=False, n_samples=100):
    ig_img_total, ig_meta_total, n = 0.0, 0.0, 0
    def forward_fn(img, meta):
        out = model(img, meta)
        if is_metablock: out = out[0]
        return F.softmax(out, dim=1)
    ig = IntegratedGradients(forward_fn)
    for img, meta, label in loader:
        img, meta, label = img.to(device), meta.to(device), label.to(device)
        for i in range(0, img.size(0), 4):
            sub_img = img[i:i+4]
            sub_meta = meta[i:i+4]
            sub_label = label[i:i+4]
            baseline_img = torch.zeros_like(sub_img)
            baseline_meta = torch.zeros_like(sub_meta)
            attr_img, attr_meta = ig.attribute((sub_img, sub_meta), baselines=(baseline_img, baseline_meta),
                                                target=sub_label, n_steps=20, internal_batch_size=4)
            ig_img_total += attr_img.abs().sum().item()
            ig_meta_total += attr_meta.abs().sum().item()
            n += sub_img.size(0)
            del attr_img, attr_meta
            torch.cuda.empty_cache()
            if n >= n_samples: break
        if n >= n_samples: break
    total = ig_img_total + ig_meta_total + 1e-9
    return ig_img_total / total, ig_meta_total / total

def gate_importance(model, loader):
    gates = []
    for img, meta, label in loader:
        img, meta = img.to(device), meta.to(device)
        with torch.no_grad():
            _, gate = model(img, meta)
        gates.append(gate.mean().item())
    return float(np.mean(gates))

xai_results = []
for seed in sorted(pred_df['seed'].unique()):
    seed_df = pred_df[pred_df['seed'] == seed]
    isic_ids = seed_df['isic_id'].tolist()
    labels = seed_df['true_label'].tolist()
    ds = XAIDataset(isic_ids, labels)
    loader = DataLoader(ds, batch_size=32, shuffle=False, num_workers=0)

    fusion_path = os.path.join(CKPT_DIR, f'fusion_seed{seed}.pth')
    mb_path = os.path.join(CKPT_DIR, f'metablock_seed{seed}.pth')
    if not (os.path.exists(fusion_path) and os.path.exists(mb_path)):
        print(f"Seed {seed}: checkpoint missing, skipping"); continue

    print(f"\n--- Seed {seed}: loading checkpoints ---")
    fusion_model = load_model(FusionModel, fusion_path, META_DIM, name="Fusion")
    mb_model = load_model(MetaBlockModel, mb_path, META_DIM, name="MetaBlock")

    v_full = batch_accuracy(fusion_model, loader)
    v_imgonly = batch_accuracy(fusion_model, loader, zero_meta=True)
    v_metaonly = batch_accuracy(fusion_model, loader, zero_img=True)
    v_none = 0.5

    ablation_img_importance = v_full - v_metaonly
    ablation_meta_importance = v_full - v_imgonly

    shap_img = 0.5 * ((v_imgonly - v_none) + (v_full - v_metaonly))
    shap_meta = 0.5 * ((v_metaonly - v_none) + (v_full - v_imgonly))

    ig_img_frac, ig_meta_frac = ig_attributions(fusion_model, loader, is_metablock=False)

    random_model = FusionModel(META_DIM).to(device).eval()
    ig_img_rand, ig_meta_rand = ig_attributions(random_model, loader, is_metablock=False)

    mean_gate = gate_importance(mb_model, loader)

    xai_results.append({
        'seed': seed,
        'v_full': v_full, 'v_imgonly': v_imgonly, 'v_metaonly': v_metaonly,
        'ablation_img': ablation_img_importance, 'ablation_meta': ablation_meta_importance,
        'shap_img': shap_img, 'shap_meta': shap_meta,
        'ig_img_frac': ig_img_frac, 'ig_meta_frac': ig_meta_frac,
        'ig_img_frac_RANDOM': ig_img_rand, 'ig_meta_frac_RANDOM': ig_meta_rand,
        'mb_mean_gate': mean_gate,
    })
    print(f"Seed {seed} done:", xai_results[-1])

xai_df = pd.DataFrame(xai_results)
xai_df.to_csv('/kaggle/working/xai_full_results.csv', index=False)
print("\n===== FULL XAI RESULTS (all seeds) =====")
print(xai_df)

print("\n===== FAITHFULNESS (Spearman vs ablation, image importance) =====")
if len(xai_df) >= 3:
    rho_shap, p_shap = spearmanr(xai_df['ablation_img'], xai_df['shap_img'])
    rho_ig, p_ig = spearmanr(xai_df['ablation_img'], xai_df['ig_img_frac'])
    print(f"Shapley vs Ablation: rho={rho_shap:.4f}, p={p_shap:.4f}")
    print(f"IG vs Ablation:      rho={rho_ig:.4f}, p={p_ig:.4f}")
else:
    print("Need >=3 seeds for meaningful Spearman correlation.")

print("\n===== RANDOMIZATION SANITY CHECK =====")
print(xai_df[['seed', 'ig_img_frac', 'ig_img_frac_RANDOM']])

print("\nCAVEATS:")
print("1. Metadata here uses GLOBAL median/dummy encoding, not per-seed train-only stats — fine for XAI, not exact accuracy match.")
print("2. If load_state_dict printed missing/unexpected keys, FusionModel/MetaBlockModel here don't exactly match your training classes — send those if so.")

print("\n\n========== ALL DONE: metrics CSV printed above, XAI saved to /kaggle/working/xai_full_results.csv ==========")

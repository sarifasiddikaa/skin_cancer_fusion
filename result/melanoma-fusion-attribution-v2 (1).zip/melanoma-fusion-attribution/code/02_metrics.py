
#### CELL 0
# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# Use the kagglehub client library to attach Kaggle resources like competitions, datasets, and models to your session
# Learn more about kagglehub: https://github.com/Kaggle/kagglehub/blob/main/README.md

import kagglehub
# kagglehub.dataset_download('<owner>/<dataset-slug>')

#### CELL 1
import pandas as pd, numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, f1_score
from scipy.stats import ttest_rel, wilcoxon

pred_df = pd.read_csv('/kaggle/input/datasets/sarifasiddikaa/final-results-15k/final_predictions_per_sample.csv')

def compute_metrics(df, prob_col):
    y_true = df['true_label'].values
    y_prob = df[prob_col].values
    y_pred = (y_prob >= 0.5).astype(int)

    auroc = roc_auc_score(y_true, y_prob)
    auprc = average_precision_score(y_true, y_prob)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    sensitivity = tp / (tp + fn)
    specificity = tn / (tn + fp)
    f1 = f1_score(y_true, y_pred)
    balanced_acc = (sensitivity + specificity) / 2

    bins = np.linspace(0, 1, 11)
    ece = 0
    for i in range(10):
        mask = (y_prob >= bins[i]) & (y_prob < bins[i+1])
        if mask.sum() > 0:
            bin_acc = (y_pred[mask] == y_true[mask]).mean()
            bin_conf = y_prob[mask].mean()
            ece += (mask.sum() / len(y_prob)) * abs(bin_acc - bin_conf)

    return {'AUROC': auroc, 'AUPRC': auprc, 'Sensitivity': sensitivity,
            'Specificity': specificity, 'F1': f1, 'BalancedAcc': balanced_acc, 'ECE': ece}

print("===== PER-SEED METRICS =====")
fusion_accs, mb_accs = [], []
for seed in sorted(pred_df['seed'].unique()):
    seed_df = pred_df[pred_df['seed']==seed]
    fusion_m = compute_metrics(seed_df, 'fusion_prob_1')
    mb_m = compute_metrics(seed_df, 'mb_prob_1')
    print(f"\nSeed {seed}:")
    print(f"  Fusion:    {fusion_m}")
    print(f"  MetaBlock: {mb_m}")
    fusion_accs.append((seed_df['fusion_prob_1']>=0.5).astype(int).eq(seed_df['true_label']).mean())
    mb_accs.append((seed_df['mb_prob_1']>=0.5).astype(int).eq(seed_df['true_label']).mean())

print("\n===== POOLED METRICS (all seeds combined) =====")
print("Fusion:   ", compute_metrics(pred_df, 'fusion_prob_1'))
print("MetaBlock:", compute_metrics(pred_df, 'mb_prob_1'))

print("\n===== 95% CI (bootstrap, pooled) =====")
def bootstrap_ci(df, prob_col, metric_fn, n_boot=1000, seed=0):
    rng = np.random.RandomState(seed)
    vals = []
    n = len(df)
    for _ in range(n_boot):
        idx = rng.randint(0, n, n)
        sample = df.iloc[idx]
        try:
            vals.append(metric_fn(sample, prob_col))
        except Exception:
            continue
    lo, hi = np.percentile(vals, [2.5, 97.5])
    return np.mean(vals), lo, hi

for name, col in [('Fusion','fusion_prob_1'), ('MetaBlock','mb_prob_1')]:
    mean_auc, lo, hi = bootstrap_ci(pred_df, col, lambda d,c: roc_auc_score(d['true_label'], d[c]))
    print(f"{name} AUROC: {mean_auc:.4f} (95% CI {lo:.4f}-{hi:.4f})")

print("\n===== PAIRED STATISTICAL TEST (MetaBlock vs Fusion, per-seed accuracy) =====")
print("Fusion accs:   ", [f"{a:.4f}" for a in fusion_accs])
print("MetaBlock accs:", [f"{a:.4f}" for a in mb_accs])

t_stat, t_p = ttest_rel(mb_accs, fusion_accs)
print(f"\nPaired t-test: t={t_stat:.4f}, p={t_p:.4f}")

try:
    w_stat, w_p = wilcoxon(mb_accs, fusion_accs)
    print(f"Wilcoxon signed-rank: W={w_stat:.4f}, p={w_p:.4f}")
except Exception as e:
    print("Wilcoxon not applicable:", e)

print("\nNote: n=5 seeds is small; p-values are indicative, not strongly conclusive.")

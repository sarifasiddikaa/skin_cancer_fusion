# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

# Use the kagglehub client library to attach Kaggle resources like competitions, datasets, and models to your session
# Learn more about kagglehub: https://github.com/Kaggle/kagglehub/blob/main/README.md

import kagglehub
# kagglehub.dataset_download('<owner>/<dataset-slug>')
import pandas as pd, numpy as np, os, torch, torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torchvision import transforms
import torchvision.models as models
from sklearn.model_selection import StratifiedGroupKFold, train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
from torch.cuda.amp import autocast, GradScaler

IMAGE_FOLDER = '/kaggle/input/datasets/iamtrina/isic-images-full/images_full'
df = pd.read_csv('/kaggle/input/datasets/sarifasiddikatrina/isic-dicm/train-set-metadata.csv')
mel_full = df[df['class']==1]
non_mel_full = df[df['class']==0].sample(n=len(mel_full), random_state=42)
full_subset = pd.concat([mel_full, non_mel_full]).reset_index(drop=True)
full_subset['patient_id'] = full_subset['patient_id'].astype(str)
full_subset.loc[full_subset['patient_id']=='nan','patient_id'] = 'unknown_' + full_subset.index[full_subset['patient_id']=='nan'].astype(str)

print("Validating images...")
corrupted = []
for i, row in full_subset.iterrows():
    p = f"{IMAGE_FOLDER}/{row['isic_id']}.jpg"
    if not os.path.exists(p): corrupted.append(row['isic_id']); continue
    try: Image.open(p).convert('RGB')
    except Exception: corrupted.append(row['isic_id'])
full_subset = full_subset[~full_subset['isic_id'].isin(corrupted)].reset_index(drop=True)
print("Usable total:", len(full_subset), "| Corrupted/missing:", len(corrupted))

cat_cols = ['sex', 'anatom_site_general', 'personal_hx_mm', 'family_hx_mm']
numeric_cols = ['age_approx', 'clin_size_long_diam_mm']

def encode_metadata(df_in, medians, reference_columns=None):
    df_cat = pd.get_dummies(df_in[cat_cols].astype(str))
    df_num = df_in[numeric_cols].fillna(medians)
    df_encoded = pd.concat([df_num, df_cat], axis=1)
    if reference_columns is not None:
        df_encoded = df_encoded.reindex(columns=reference_columns, fill_value=0)
    return df_encoded

class SkinFusionDataset(Dataset):
    def __init__(self, df, meta_features, labels, folder, transform=None):
        self.df = df.reset_index(drop=True)
        self.meta_features = meta_features.reset_index(drop=True)
        self.labels = labels
        self.transform = transform
        self.image_lookup = {f: os.path.join(folder, f) for f in os.listdir(folder)}
        self.image_cache = {}
        self.resize = transforms.Resize((224,224))
    def __len__(self): return len(self.df)
    def __getitem__(self, idx):
        img_name = self.df.loc[idx, 'img_id']
        if img_name not in self.image_cache:
            raw = Image.open(self.image_lookup[img_name]).convert('RGB')
            self.image_cache[img_name] = self.resize(raw)
        image = self.image_cache[img_name].copy()
        if self.transform: image = self.transform(image)
        meta = torch.tensor(self.meta_features.iloc[idx].values.astype('float32'))
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return image, meta, label

transform = transforms.Compose([transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])])
train_transform = transforms.Compose([transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(20), transforms.ColorJitter(brightness=0.2, contrast=0.2), transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])])

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.backends.cudnn.benchmark = True
print("Device:", device)

def train_one_epoch(model, loader, criterion, optimizer, device, scaler):
    model.train()
    for images, metas, labels in loader:
        images, metas, labels = images.to(device), metas.to(device), labels.to(device)
        optimizer.zero_grad()
        with autocast():
            outputs = model(images, metas)
            loss = criterion(outputs, labels)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

def evaluate(model, loader, device):
    model.eval(); correct, total = 0, 0
    with torch.no_grad():
        for images, metas, labels in loader:
            images, metas, labels = images.to(device), metas.to(device), labels.to(device)
            with autocast():
                outputs = model(images, metas)
            _, preds = torch.max(outputs, 1)
            correct += (preds==labels).sum().item(); total += labels.size(0)
    return correct/total

FREEZE_PATTERN = ['0.8.']

class FusionModel(nn.Module):
    def __init__(self, meta_input_dim, num_classes):
        super().__init__()
        eff = models.efficientnet_b3(weights='IMAGENET1K_V1')
        self.image_branch = nn.Sequential(eff.features, eff.avgpool)
        for name, p in self.image_branch.named_parameters():
            p.requires_grad = any(name.startswith(pat) for pat in FREEZE_PATTERN)
        self.meta_branch = nn.Sequential(nn.Linear(meta_input_dim, 64), nn.ReLU(), nn.Linear(64,32), nn.ReLU())
        self.classifier = nn.Sequential(nn.Linear(1536+32, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        i = self.image_branch(image).flatten(1)
        m = self.meta_branch(meta)
        return self.classifier(torch.cat([i,m], dim=1))

class MetaBlock(nn.Module):
    def __init__(self, image_feat_dim, meta_input_dim, num_classes):
        super().__init__()
        eff = models.efficientnet_b3(weights='IMAGENET1K_V1')
        self.image_branch = nn.Sequential(eff.features, eff.avgpool)
        for name, p in self.image_branch.named_parameters():
            p.requires_grad = any(name.startswith(pat) for pat in FREEZE_PATTERN)
        self.meta_gate = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Sigmoid())
        self.meta_bias = nn.Sequential(nn.Linear(meta_input_dim, image_feat_dim), nn.Tanh())
        self.classifier = nn.Sequential(nn.Linear(image_feat_dim, 64), nn.ReLU(), nn.Dropout(0.5), nn.Linear(64, num_classes))
    def forward(self, image, meta):
        img_feat = self.image_branch(image).flatten(1)
        gate = self.meta_gate(meta); bias = self.meta_bias(meta)
        return self.classifier(img_feat*gate + bias)

def get_probs(model, loader, device):
    model.eval(); all_probs = []
    with torch.no_grad():
        for images, metas, labels in loader:
            images, metas = images.to(device), metas.to(device)
            with autocast():
                out = torch.softmax(model(images, metas), dim=1)
            all_probs.append(out.cpu())
    return torch.cat(all_probs)

def run_stage(stage_name, data_fraction, n_seeds, epochs_fusion, epochs_mb, save_predictions=False):
    print(f"\n{'='*20} STAGE: {stage_name} ({int(data_fraction*100)}%, {n_seeds} seed(s)) {'='*20}")
    if data_fraction < 1.0:
        stage_subset, _ = train_test_split(full_subset, train_size=data_fraction,
                                            stratify=full_subset['class'], random_state=1)
        stage_subset = stage_subset.reset_index(drop=True)
    else:
        stage_subset = full_subset.copy()

    all_predictions = []
    stage_results = []

    for seed in range(1, n_seeds+1):
        print(f"\n--- {stage_name} Seed {seed} ---")
        torch.manual_seed(seed); np.random.seed(seed); torch.cuda.manual_seed_all(seed)

        sgkf1 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
        trainval_idx, test_idx = next(sgkf1.split(stage_subset, stage_subset['class'], groups=stage_subset['patient_id']))
        trainval_df = stage_subset.iloc[trainval_idx].reset_index(drop=True)
        test_df = stage_subset.iloc[test_idx].reset_index(drop=True)
        sgkf2 = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
        train_idx, val_idx = next(sgkf2.split(trainval_df, trainval_df['class'], groups=trainval_df['patient_id']))
        train_df = trainval_df.iloc[train_idx].reset_index(drop=True)
        val_df = trainval_df.iloc[val_idx].reset_index(drop=True)

        overlap = len(set(train_df['patient_id']) & set(test_df['patient_id']))
        print("Patient overlap (must be 0):", overlap)
        if overlap > 0:
            print("WARNING: overlap, skipping seed")
            continue

        for d in [train_df, val_df, test_df]:
            d['img_id'] = d['isic_id'] + '.jpg'
            for col in cat_cols: d[col] = d[col].astype(str)

        train_medians = train_df[numeric_cols].median()
        train_meta = encode_metadata(train_df, train_medians)
        ref_cols = train_meta.columns
        val_meta = encode_metadata(val_df, train_medians, ref_cols)
        test_meta = encode_metadata(test_df, train_medians, ref_cols)
        META_DIM = len(ref_cols)

        le = LabelEncoder(); le.fit(train_df['class'])
        train_labels = le.transform(train_df['class'])
        val_labels = le.transform(val_df['class'])
        test_labels = le.transform(test_df['class'])

        train_ds = SkinFusionDataset(train_df, train_meta, train_labels, IMAGE_FOLDER, train_transform)
        val_ds = SkinFusionDataset(val_df, val_meta, val_labels, IMAGE_FOLDER, transform)
        test_ds = SkinFusionDataset(test_df, test_meta, test_labels, IMAGE_FOLDER, transform)
        train_loader = DataLoader(train_ds, batch_size=96, shuffle=True, num_workers=0, pin_memory=True)
        val_loader = DataLoader(val_ds, batch_size=96, shuffle=False, num_workers=0, pin_memory=True)
        test_loader = DataLoader(test_ds, batch_size=96, shuffle=False, num_workers=0, pin_memory=True)

        class_weights = torch.tensor(compute_class_weight('balanced', classes=np.unique(train_labels), y=train_labels), dtype=torch.float32).to(device)
        criterion = nn.CrossEntropyLoss(weight=class_weights)

        def train_best(model_cls, epochs, **kwargs):
            m = model_cls(**kwargs).to(device)
            opt = torch.optim.Adam(filter(lambda p: p.requires_grad, m.parameters()), lr=1e-4, weight_decay=1e-3)
            scaler = GradScaler()
            best_val, best_state = 0, None
            for ep in range(epochs):
                train_one_epoch(m, train_loader, criterion, opt, device, scaler)
                val_acc = evaluate(m, val_loader, device)
                if val_acc > best_val:
                    best_val = val_acc
                    best_state = {k: v.clone() for k, v in m.state_dict().items()}
            m.load_state_dict(best_state)
            test_acc = evaluate(m, test_loader, device)
            return test_acc, m

        fusion_acc, fusion_model = train_best(FusionModel, epochs_fusion, meta_input_dim=META_DIM, num_classes=2)
        mb_acc, mb_model = train_best(MetaBlock, epochs_mb, image_feat_dim=1536, meta_input_dim=META_DIM, num_classes=2)

        print(f"Fusion: {fusion_acc:.4f} | MetaBlock: {mb_acc:.4f} | MB>=Fusion: {mb_acc>=fusion_acc}")
        stage_results.append({'seed': seed, 'fusion_acc': fusion_acc, 'mb_acc': mb_acc})

        if save_predictions:
            fusion_probs = get_probs(fusion_model, test_loader, device)
            mb_probs = get_probs(mb_model, test_loader, device)
            torch.save(fusion_model.state_dict(), f'/kaggle/working/fusion_seed{seed}.pth')
            torch.save(mb_model.state_dict(), f'/kaggle/working/metablock_seed{seed}.pth')
            for i in range(len(test_df)):
                all_predictions.append({
                    'seed': seed, 'isic_id': test_df.iloc[i]['isic_id'],
                    'true_label': int(test_labels[i]),
                    'fusion_prob_0': fusion_probs[i,0].item(), 'fusion_prob_1': fusion_probs[i,1].item(),
                    'mb_prob_0': mb_probs[i,0].item(), 'mb_prob_1': mb_probs[i,1].item()
                })

    results_df = pd.DataFrame(stage_results)
    print(f"\n{stage_name} SUMMARY:")
    print(results_df)
    if len(results_df) > 0:
        print(results_df[['fusion_acc','mb_acc']].agg(['mean','std']))

    if save_predictions and all_predictions:
        pred_df = pd.DataFrame(all_predictions)
        pred_df.to_csv('/kaggle/working/final_predictions_per_sample.csv', index=False)
        print("Saved per-sample predictions:", len(pred_df), "rows")

    return results_df

# ===== STAGE 1: SMOKE TEST =====
smoke_results = run_stage("SMOKE TEST", data_fraction=0.10, n_seeds=1, epochs_fusion=4, epochs_mb=5)

# ===== STAGE 2: PILOT =====
pilot_results = run_stage("PILOT", data_fraction=0.25, n_seeds=2, epochs_fusion=8, epochs_mb=10)

# ===== STAGE 3: MID-SCALE =====
midscale_results = run_stage("MID-SCALE", data_fraction=0.50, n_seeds=3, epochs_fusion=12, epochs_mb=14)

# ===== STAGE 4: FINAL (100%, 5 seeds, save predictions) =====
final_results = run_stage("FINAL", data_fraction=1.0, n_seeds=5, epochs_fusion=15, epochs_mb=18, save_predictions=True)

print("\n\n===== ALL STAGES COMPLETE =====")
print("Smoke:", smoke_results.to_dict('records'))
print("Pilot:", pilot_results.to_dict('records'))
print("Mid-scale:", midscale_results.to_dict('records'))
print("Final:", final_results.to_dict('records'))
# Predictive performance and modality attribution in melanoma classification using dermoscopic images and clinical metadata

Supplementary data and code for the manuscript of the same title (submitted to *Computerized Medical Imaging and Graphics*).

## Contents

### data/
- `final_predictions_per_sample.csv` – test-set predicted probabilities of the Fusion (concatenation) and MetaBlock (gated) models for every test image of each run (seeds 1–5). Columns: `seed`, `isic_id`, `true_label` (1 = melanoma), `fusion_prob_0`, `fusion_prob_1`, `mb_prob_0`, `mb_prob_1`. 15,094 rows (test sets of the five runs; test sets overlap across runs).
- `baseline_predictions_per_sample.csv` – test-set predicted melanoma probabilities of the image-only (`img_prob_1`) and metadata-only (`meta_prob_1`) baselines on the same test images and seeds.
- `per_seed_metrics_all_models.csv` – per-run test metrics (AUROC, AUPRC, accuracy, balanced accuracy, sensitivity, specificity, F1, ECE) for ImageOnly, MetaOnly, Fusion and MetaBlock, seeds 1–5. Means ± sample SD of these values are reported in the manuscript (Table 4).

### code/
1. `01_train_fusion_metablock.py` – training of Fusion and MetaBlock (EfficientNet-B3 image branch; patient-identifier group-aware partitioning, seeds 1–5).
2. `02_metrics.py` – evaluation metrics.
3. `03_attribution_analysis.py` – zero-input ablation, two-player Shapley decomposition, Integrated Gradients modality fractions, MetaBlock gate magnitude, Spearman agreement.
4. `04_results_tables_figures.py` – tables and figures.
5. `05_unimodal_baselines.py` – image-only and metadata-only baselines.
6. `06_streamlit_prototype_app.py` – public browser-based research prototype (research use only; not a clinical tool).

The scripts were written as Kaggle notebook cells; input paths (`/kaggle/input/...`) must be adapted to the local location of the data.

## Source data
The images and clinical metadata come from the publicly available ISIC-DICM-17K dataset (Ahammed et al., 2025; https://doi.org/10.34970/233480). The dataset itself is not redistributed here; only image identifiers (`isic_id`) are included.

## Notes
- All values are test-set outputs of retrospective experiments on a single dataset; they do not establish clinical utility.
- Prototype: https://skin-lesion-demo-sst.streamlit.app/ ; code: https://github.com/sarifasiddikaa/skin-lesion-demo

## License
Data files: CC BY 4.0. Code: MIT.

## Citation
[Add the manuscript citation and this record's DOI after publication.]
